<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SemBranch extends Model
{
    public $timestamps = false;
}
