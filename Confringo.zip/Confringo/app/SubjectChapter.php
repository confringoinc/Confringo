<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SubjectChapter extends Model
{
    public $timestamps = false;
}
