<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PageController extends Controller
{
    public function __invoke($page){
        $title = $page;

        if($title === "index"){
            $title = "Index";
        }
        elseif($title === "about"){
            $title = "About Us";
        }
        elseif($title === "learn"){
            $title = "Let's Learn";
        }
        else{
            $title = "Temp Page";
        }

        return view('Pages.' . $page)->with('title', $title);
    }
}
