<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\SubjectChapter;
use App\SemBranch;
use App\ChapterReference;
use DB;

class AdminPagesController extends Controller
{
    public function __invoke($adminPage){
        return view('AdminPages.'.$adminPage);
    }
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function subjectStore(Request $request)
    {
        $this->validate($request, [
            'semester' => 'required',
            'branch' => 'required',
            'subject' => 'required'
        ]);
        $subject = new SemBranch();
        $subject->semester = $request->input('semester');
        $subject->branch = $request->input('branch');
        $subject->subject = $request->input('subject');

        // $subject->save();
        
        //  Here we are redirecting to subject and not insertSubject
        //  Because we had __invoke() method that is operated on different logic;
        return redirect('/insertSubject')->with('success', 'Subject Inserted');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function chapterStore(Request $request)
    {
        $this->validate($request, [
            'subject' => 'required',
            'chapter' => 'required'
        ]);

        $chapter = new SubjectChapter();
        $chapter->subject = $request->input('subject');
        $chapter->chapter = $request->input('chapter');
        $chapter->save();
        return redirect('/insertChapter')->with('success', 'Chapter Inserted');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function referenceStore(Request $request)
    {
        // Here we store values of reference 
        
        $this->validate($request, [
            'chapter' => 'required',
            'reference' => 'required'
        ]);

        $reference = new ChapterReference();
        $reference->chapter = $request->input('chapter');
        
        $temp_ref = implode('|', $request->reference);

        $reference->reference = $temp_ref;
        
        //  We serialize data for storing in database;
        
        //  echo "$request->reference";
        $reference->save();
        return redirect('/insertReference')->with('success', 'Reference Inserted!!!');
    }

    public function addItem($itemArray, $newItem){
        $itemArray[] = $newItem;

        return redirect('/insertReference');
    }
    
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function refernceStore(Request $request)
    {
        return "reference value store";
    }
    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show()
    {
        return view('AdminPages/show');
    }
}