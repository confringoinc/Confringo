<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\SemBranch;
use App\SubjectChapter;
use App\ChapterReference;
use DB;
class SemBranchesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

     /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function showSubject(Request $request)
    {
        $year = $request->input('year');
        $sem = $request->input('sem');
        $branch = $request->input('branch');
        if($sem == 1){
            $sem = (2*$year - 1);   //  Logic for getting odd SEM
        }
        else{
            $sem = (2*$year);   //  Logic for getting even SEM
        }

        //  Fetching data based on Sem and Branch
        $subject = SemBranch::select('subject')->where(['semester' => $sem, 'branch' => $branch])->get();

        //  Created array for Branch name and Subjects
        $content = [
            'branch' => $branch,
            'subject' => $subject
        ];
        return view('/dataPages.showSubject')->with('content', $content);

    }

    //  Function for showing chapters...
    /**
     * Display the specified resource.
     *
     * @param  int  $subject
     */
    public function showChapter($subject){
        $chapters = SubjectChapter::select('chapter')
                            ->where(['subject' => $subject])
                            ->get();
        $results = [
            'subject' => $subject,
            'chapters' => $chapters
        ];

        return view('dataPages.showChapter')->with('results', $results);
    }

    public function showReference($chapter){
        $references = ChapterReference::select('reference')
                            ->where(['chapter' => $chapter])
                            ->get();
        
        //  The data is fetched in Json_encoded format so 
        //  we retrive it with index 0
        $references = json_decode($references[0], true);

        //  Links were imploded with '|' hence it need to be exploded too
        $references = explode("|", $references['reference']);

        $results = [
            'chapter' => $chapter,
            'references' => $references
        ];
        
        return view('dataPages.showReference')->with("results", $results);
    }
    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
