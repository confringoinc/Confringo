<?php $__env->startSection('content'); ?>
    <h2><?php echo e($results['chapter']); ?></h2>
    
    <?php if(count($results['references']) > 0): ?>
    <ul class="list-group">
        <?php $__currentLoopData = $results['references']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ref): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(url('showReference/'.$ref.'/')); ?>">
                <li class="list-group-item list-group-item-info list-group-flush">
                    <?php echo e($ref); ?>

                </li>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <h2>No reference for this chapter</h2>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.theme', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>