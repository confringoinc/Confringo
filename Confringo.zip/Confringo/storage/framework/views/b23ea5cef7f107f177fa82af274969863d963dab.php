<?php $__env->startSection('content'); ?>
    <h3>Click on what you wish to store ?</h3>
    <a class="btn btn-primary btn-lg" href="<?php echo e(route('adminPage', 'insertSubject')); ?>" role="button">
        Subject
    </a>
    <a class="btn btn-primary btn-lg" href="<?php echo e(route('adminPage', 'insertChapter')); ?>" role="button">
        Chapter
    </a>
    <a class="btn btn-primary btn-lg" href="<?php echo e(route('adminPage', 'insertReference')); ?>" role="button">
        reference
    </a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.theme', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>