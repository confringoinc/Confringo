<?php $__env->startSection('content'); ?>
    <h2>here we are</h2>
    <p><?php echo e($chapters); ?></p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.theme', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>