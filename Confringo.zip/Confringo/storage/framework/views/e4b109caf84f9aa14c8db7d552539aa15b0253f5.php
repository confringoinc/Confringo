<nav class="navbar navbar-inverse">
    <div class="container">
        <div id="navbar" class="collapse-navbar collapse">
            <ul class="nav navbar-nav">
                <li class="active"><a href="#">Index</a></li>
                <li><a href="#">About Us</a></li>
                <li><a href="#">Temp</a></li>
            </ul>
        </div>
    </div>
</nav>