<?php $__env->startSection('content'); ?>
    <?php if(count($content['subject']) > 0): ?>
        <h2>Displaying chapters for subject <?php echo e($content['branch']); ?></h2>
        <ul class="list-group">
        <?php $__currentLoopData = $content['subject']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(url('showChapter/'.$subject['subject'].'/')); ?>">
                <li class="list-group-item list-group-item-info list-group-flush">
                    <?php echo e($subject['subject']); ?>

                </li>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    <?php else: ?>
        <h2>No Subject found for your Branch: <?php echo e($content['branch']); ?></h2>
        <p>Sunday ko aana mast Nah Dhoke!!!</p>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.theme', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>