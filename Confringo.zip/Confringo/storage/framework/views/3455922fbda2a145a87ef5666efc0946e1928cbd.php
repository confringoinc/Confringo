<?php $__env->startSection('content'); ?>
<h1>Insert Reference</h1>
<h2>Saving is Diabled For moment</h2>
    <h2>Make your changes</h2>
    <?php $ref = array(); ?>
    <?php echo Form::open(['action' => 'AdminPagesController@referenceStore', 'method' => 'POST']); ?>

        <div class="row">
            <div calss="col-md-12 col-sm-12">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th style="text-align: center"><h3>Chapter</h3></th>
                            <th style="text-align: center"><h3>Reference</h3></th>
                            <th style="text-align: center"><a href="#" class="btn btn-info btn-lg addRow">+</a></th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><input type="text" name="chapter" id="chapter" class="form-control"></td>
                            <td><input type="text" name="reference[]" id="reference" class="form-control"></td>
                            <td style="text-align: center"><a href="#" class="btn btn-danger btn-lg">-</a></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="row">
            <?php echo e(Form::submit('Submit', ['class' => 'btn btn-primary btn-lg btn-block'])); ?>

            
        </div>
    <?php echo Form::close(); ?>


    
    <script type="text/javascript">
        $('.addRow').on('click', function(){
            addRow();
        })

        function addRow(){
            var chap = $('#chapter').val();
            var ref = $('#reference').val();
            // Check if initial values are filled

            if(chap == "" || ref == ""){
               alert("Enter a chapter and reference initially"); 
               return;
            }

            var tr = '<tr>' +
                        '<td><input type="text" name="chapter" value="' + chap + '"  id="chapter" class="form-control" disabled></td>' +
                        '<td><input type="text" name="reference[]" id="reference" class="form-control"></td>' + 
                        '<td style="text-align: center"><a href="#" class="btn btn-danger btn-lg remove">-</a></td>' +
                        '</tr>';
            $('tbody').append(tr);
        };

        $('tbody').on('click', '.remove', function(){
            $(this).parent().parent().remove();
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.theme', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>