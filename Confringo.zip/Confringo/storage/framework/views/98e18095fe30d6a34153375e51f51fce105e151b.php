<?php $__env->startSection('content'); ?>
    <h2>Here you will select your year branch and subject</h2>
    <p>According you will be suggested with the best study material</p>
    <?php echo Form::open(['action' => 'SemBranchesController@showSubject', 'method' => 'POST']); ?>

        <div class="from-group">
            <?php echo e(Form::label('year', 'Year')); ?>

            <select name="year" class="form-control"><span class="caret"></span>
                <option value="1">1<sup>st</sup></option>
                <option value="2">2<sup>nd</sup></option>
                <option value="3">3<sup>rd</sup></option>
                <option value="4">4<sup>th</sup></option>
            </select>
        </div>
        <div class="from-group">
            <?php echo e(Form::label('sem', 'Semester')); ?>

            <select name="sem" class="form-control"><span class="caret"></span>
                <option value="1">Odd</option>
                <option value="2">Even</option>
            </select>
        </div>
        <div class="from-group">
            <?php echo e(Form::label('year', 'Year')); ?>

            <select name="branch" class="form-control"><span class="caret"></span>
                <option value="IT">Information Technology</option>
                <option value="CP">Computer Engineering</option>
                <option value="EC">Electical & Communication</option>
                <option value="EE">Electonics</option>
            </select>
        </div>

        <?php echo e(Form::submit('Submit', ['class' => 'btn btn-primary'])); ?>

    <?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.theme', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>