<?php $__env->startSection('content'); ?>
    <h2><?php echo e($title); ?></h2>
    <p>About us content is here.</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.theme', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>