<?php $__env->startSection('content'); ?>
<h1>Insert Chapter</h1>
<h2>Saving is Diabled For moment</h2>
    <h2>Make your changes</h2>
    <?php echo Form::open(['action', 'AdminPagesController@chapterStore', 'method' => 'POST']); ?>

    <div class="form-group">
        <?php echo e(Form::label('subject', 'Subject')); ?>

        <?php echo e(Form::text('subject', '', ['class' => 'form-control', 'placeholder' => 'Information Security'])); ?>

    </div>

    <div class="form-group">
        <?php echo e(Form::label('chapter', 'Chapter')); ?>

        <?php echo e(Form::text('chapter', '', ['class' => 'form-control', 'placeholder' => 'Asymmetric Encryption'])); ?>

    </div>
        <?php echo e(Form::submit('Submit', ['class' => 'btn btn-primary'])); ?>

    <?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.theme', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>