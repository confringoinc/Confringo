<nav class="navbar navbar-inverse">
    <div class="container">
        <div class="navbar-header">  
        <div class="collapse navbar-collapse" id="app-navbar-collapse">
            <ul class="nav navbar-nav">
              <li><a href="<?php echo e(route('page', '')); ?>" class="navbar-brand"><?php echo e(config('app.name', 'GetHere')); ?></a></li>
                <li><a href="<?php echo e(route('page', 'index')); ?>">Index</a></li>
                <li><a href="<?php echo e(route('page', 'about')); ?>">About</a></li>
                <li><a href="<?php echo e(route('page', 'temp')); ?>">Temp</a></li>
                
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                      Year <span class="caret"></span>
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                      <li><a class="dropdown-item" href="#">1<sup>st</sup> Year</a></li>
                      <li><a class="dropdown-item" href="#">2<sup>nd</sup> Year</a></li>
                      <li><a class="dropdown-item" href="#">3<sup>rd</sup> Year</a></li>
                      <li><a class="dropdown-item" href="#">4<sup>th</sup> Year</a></li>
                    </ul>
                </li>
                
              </ul>
        </div>
    </div>
  </nav>