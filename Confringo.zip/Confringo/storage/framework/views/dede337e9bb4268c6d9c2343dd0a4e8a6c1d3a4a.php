<?php $__env->startSection('content'); ?>

    <h2><?php echo e($results['subject']); ?></h2>

    <?php if(count($results['chapters']) > 0): ?>
    <ul class="list-group">
        <?php $__currentLoopData = $results['chapters']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chapter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(url('showReference/'.$chapter['chapter'].'/')); ?>">
                <li class="list-group-item list-group-item-info list-group-flush">
                    <?php echo e($chapter['chapter']); ?>

                </li>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <h2>No Chapter Found in this Subject</h2>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.theme', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>