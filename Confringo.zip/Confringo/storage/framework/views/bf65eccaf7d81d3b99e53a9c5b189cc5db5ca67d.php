<?php $__env->startSection('content'); ?>
    <div class="card-body">
        <div class="row">
            <div class="col-md-8 col-sm-8">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th style="text-align: center"><a href="#" class="btn btn-info addRow">+</a></th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr> 
                            <td style="text-align: center"><a href="#" class="btn btn-danger" id="remove">-</a></td>
                        </tr>;   
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <script type="text/javascript">
        $('.addRow').on('click', function(){
            addRow();
        });

        function addRow(){
            var tr = '<tr>' + 
                '<td style="text-align: center"><a href="#" class="btn btn-danger remove">-</a></td>' + 
                '</tr>';
            $('tbody').append(tr);
        };
        $('tbody').on('click', '.remove', function(){
            $(this).parent().remove();
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.theme', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>