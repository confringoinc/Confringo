<?php $__env->startSection('content'); ?>
<h1>Saving is Diabled For moment</h1>
    <h2>Make your changes</h2>
    <?php echo Form::open(['action' => 'AdminPagesController@subjectStore', 'method' => 'POST']); ?>

        <div class="form-group">
            <?php echo e(Form::label('Sem', 'Semester')); ?>

            <select name="semester" class="form-control">
                <?php for($i = 1; $i <= 8; $i++): ?>
                    <option value="<?php echo e($i); ?>">Sem - <?php echo e($i); ?></option>
                <?php endfor; ?>
            </select>
        </div>

        <div class="form-group">
            <?php echo e(Form::label('branch', 'Branch')); ?>

            <select name="branch" class="form-control">
                <option value="IT">Information Technology</option>
                <option value="CP">Computer Programming</option>
                <option value="EC">Electrical & Communication</option>
                <option value="EE">Electronics </option>
            </select>
        </div>

        <div class="form-group">
            <?php echo e(Form::label('subject', 'Subject')); ?>

            <?php echo e(Form::text('subject', '', ['class' => 'form-control', 'placeholder' => 'Information Security'])); ?>

        </div>

        <?php echo e(Form::submit('Submit', ['class' => 'btn btn-primary'])); ?>

    <?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.theme', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>