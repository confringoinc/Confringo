@extends('layout.theme')

@section('content')
    <h2>{{$results['chapter']}}</h2>
    
    @if(count($results['references']) > 0)
    <ul class="list-group">
        @foreach($results['references'] as $ref)
            <a href="{{ url('showReference/'.$ref.'/') }}">
                <li class="list-group-item list-group-item-info list-group-flush">
                    {{$ref}}
                </li>
            </a>
        @endforeach
    @else
        <h2>No reference for this chapter</h2>
    @endif
@endsection