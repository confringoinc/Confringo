@extends('layout.theme')

@section('content')

    <h2>{{$results['subject']}}</h2>

    @if(count($results['chapters']) > 0)
    <ul class="list-group">
        @foreach($results['chapters'] as $chapter)
            <a href="{{ url('showReference/'.$chapter['chapter'].'/') }}">
                <li class="list-group-item list-group-item-info list-group-flush">
                    {{$chapter['chapter']}}
                </li>
            </a>
        @endforeach
    @else
        <h2>No Chapter Found in this Subject</h2>
    @endif
@endsection