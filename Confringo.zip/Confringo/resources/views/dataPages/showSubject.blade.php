@extends('layout.theme')

@section('content')
    @if(count($content['subject']) > 0)
        <h2>Displaying chapters for subject {{$content['branch']}}</h2>
        <ul class="list-group">
        @foreach($content['subject'] as $subject)
            <a href="{{ url('showChapter/'.$subject['subject'].'/') }}">
                <li class="list-group-item list-group-item-info list-group-flush">
                    {{$subject['subject']}}
                </li>
            </a>
        @endforeach
        </ul>
    @else
        <h2>No Subject found for your Branch: {{$content['branch']}}</h2>
        <p>Sunday ko aana mast Nah Dhoke!!!</p>
    @endif
@endsection