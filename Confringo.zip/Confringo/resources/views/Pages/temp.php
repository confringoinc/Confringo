@extends('layout.theme')

@section('content')
    <h1>{{$title}}</h1>
    <p>This is a temporary page</p>
@endsection