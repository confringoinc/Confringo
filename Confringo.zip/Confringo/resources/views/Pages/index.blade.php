@extends('layout.theme')

@section('content')
    <h2>{{$title}}</h2>
    <p>Here content related to main page will be found</p>
@endsection