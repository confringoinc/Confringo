@extends('layout.theme')

@section('content')
    <h2>{{$title}}</h2>
    <p>About us content is here.</p>
@endsection