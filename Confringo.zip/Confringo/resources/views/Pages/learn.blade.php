@extends('layout.theme')

@section('content')
    <h2>Here you will select your year branch and subject</h2>
    <p>According you will be suggested with the best study material</p>
    {!! Form::open(['action' => 'SemBranchesController@showSubject', 'method' => 'POST']) !!}
        <div class="from-group">
            {{Form::label('year', 'Year')}}
            <select name="year" class="form-control"><span class="caret"></span>
                <option value="1">1<sup>st</sup></option>
                <option value="2">2<sup>nd</sup></option>
                <option value="3">3<sup>rd</sup></option>
                <option value="4">4<sup>th</sup></option>
            </select>
        </div>
        <div class="from-group">
            {{Form::label('sem', 'Semester')}}
            <select name="sem" class="form-control"><span class="caret"></span>
                <option value="1">Odd</option>
                <option value="2">Even</option>
            </select>
        </div>
        <div class="from-group">
            {{Form::label('year', 'Year')}}
            <select name="branch" class="form-control"><span class="caret"></span>
                <option value="IT">Information Technology</option>
                <option value="CP">Computer Engineering</option>
                <option value="EC">Electical & Communication</option>
                <option value="EE">Electonics</option>
            </select>
        </div>

        {{Form::submit('Submit', ['class' => 'btn btn-primary'])}}
    {!! Form::close() !!}
@endsection