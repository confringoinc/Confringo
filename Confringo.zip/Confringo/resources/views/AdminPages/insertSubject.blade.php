@extends('layout.theme')

@section('content')
<h1>Insert Subject</h1>
<h2>Saving is Diabled For moment</h2>
    <h2>Make your changes</h2>
    {!! Form::open(['action' => 'AdminPagesController@subjectStore', 'method' => 'POST']) !!}
        <div class="form-group">
            {{Form::label('Sem', 'Semester')}}
            <select name="semester" class="form-control">
                @for($i = 1; $i <= 8; $i++)
                    <option value="{{$i}}">Sem - {{$i}}</option>
                @endfor
            </select>
        </div>

        <div class="form-group">
            {{Form::label('branch', 'Branch')}}
            <select name="branch" class="form-control">
                <option value="IT">Information Technology</option>
                <option value="CP">Computer Programming</option>
                <option value="EC">Electrical & Communication</option>
                <option value="EE">Electronics </option>
            </select>
        </div>

        <div class="form-group">
            {{Form::label('subject', 'Subject')}}
            {{Form::text('subject', '', ['class' => 'form-control', 'placeholder' => 'Information Security'])}}
        </div>

        {{Form::submit('Submit', ['class' => 'btn btn-primary'])}}
    {!! Form::close() !!}
@endsection