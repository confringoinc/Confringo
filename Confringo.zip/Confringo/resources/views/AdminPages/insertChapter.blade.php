@extends('layout.theme')

@section('content')
<h1>Insert Chapter</h1>
<h2>Saving is Diabled For moment</h2>
    <h2>Make your changes</h2>
    {!! Form::open(['action', 'AdminPagesController@chapterStore', 'method' => 'POST']) !!}
    <div class="form-group">
        {{Form::label('subject', 'Subject')}}
        {{Form::text('subject', '', ['class' => 'form-control', 'placeholder' => 'Information Security'])}}
    </div>

    <div class="form-group">
        {{Form::label('chapter', 'Chapter')}}
        {{Form::text('chapter', '', ['class' => 'form-control', 'placeholder' => 'Asymmetric Encryption'])}}
    </div>
        {{Form::submit('Submit', ['class' => 'btn btn-primary'])}}
    {!! Form::close() !!}
@endsection