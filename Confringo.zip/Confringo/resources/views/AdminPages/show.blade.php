@extends('layout.theme')

@section('content')
    <h3>Click on what you wish to store ?</h3>
    <a class="btn btn-primary btn-lg" href="{{ route('adminPage', 'insertSubject') }}" role="button">
        Subject
    </a>
    <a class="btn btn-primary btn-lg" href="{{ route('adminPage', 'insertChapter') }}" role="button">
        Chapter
    </a>
    <a class="btn btn-primary btn-lg" href="{{ route('adminPage', 'insertReference') }}" role="button">
        reference
    </a>
@endsection