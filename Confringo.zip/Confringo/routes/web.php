<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

// Route::get('/index', 'PageController@index');
// Route::get('/about', 'PageController@about');
// Route::get('/temp', 'PageController@temp');

Route::get('/{page}', 'PageController')
    ->name('page')
    ->where('page', 'index|about|temp|learn');

//  Route for shwoing Subject
Route::post('/showSubject', 'SemBranchesController@showSubject');

//  Route for showing Chapters
Route::get('showChapter/{subject}', 'SemBranchesController@showChapter');

//  Route for showing Reference
Route::get('showReference/{chapter}', 'SemBranchesController@showReference');

Route::get('/show', 'AdminPagesController@show')->name('show');

Route::post('/insertSubject', 'AdminPagesController@subjectStore');
Route::post('/insertChapter', 'AdminPagesController@chapterStore');
Route::post('/insertReference', 'AdminPagesController@referenceStore');

Route::get('addItem/{itemArray}/{newItem}', 'AdminPagesController@addItem');

//  To go to a AdminPage use below route
Route::get('/{adminPage}', 'AdminPagesController')->name('adminPage');

Route::get('/temporaray', function(){
    return view('AdminPages.temporaray');
});